/* EEE3096S Practical 3: complete the four TODOs in this file.
 * See ../../../docs/prac_03.md and ST RM0091, ADC and DAC chapters.
 * Use CMSIS register names; clock, GPIO and startup helpers are supplied.
 */
#include "voltage_mirror.h"
#include "board_io.h"
#include "main.h"

bool voltage_mirror_init(void)
{
    if (!board_converters_prepare()) return false;

    /* TODO 1: ADC1: 12-bit, right-aligned, software-started single conversions,
     * channel 5 only, sampling time 239.5 ADC cycles.
     * DAC channel 1: buffer on, trigger off, initial command 2048, enable.
     * Set ADC1->CFGR1, ADC1->CHSELR, ADC1->SMPR, DAC->DHR12R1 and DAC->CR.
     * Finish by returning board_adc_enable(). Remove the false return below.
     */
    ADC1->CFGR1 = 0u;                  /* 12-bit, right-aligned, single, software start */
    ADC1->CHSELR = ADC_CHSELR_CHSEL5;  /* channel 5 only */
    ADC1->SMPR = ADC_SMPR_SMP;         /* 239.5 cycles */
    DAC->DHR12R1 = 2048u;
    DAC->CR = DAC_CR_EN1;              /* enable; BOFF1 = 0 (buffer on), TEN1 = 0 */
    return board_adc_enable();
}

bool voltage_mirror_read(uint16_t *code)
{
    /* TODO 2: reject a null pointer; clear EOC/EOS/OVR flags with W1C writes;
     * start one conversion, wait for EOC with a bounded loop, read ADC1->DR.
     * Return true only when *code contains a real acquired 12-bit result.
     * On timeout request ADSTP, then return false. Never wait forever.
     */
    if (code == NULL) return false;

    ADC1->ISR = ADC_ISR_EOC | ADC_ISR_EOS | ADC_ISR_OVR;
    ADC1->CR |= ADC_CR_ADSTART;

    for (uint32_t remaining = 5000u; remaining != 0u; --remaining)
    {
        if ((ADC1->ISR & ADC_ISR_EOC) != 0u)
        {
            uint16_t result = (uint16_t)(ADC1->DR & 0x0fffu);
            ADC1->ISR = ADC_ISR_EOS;
            *code = (result > MIRROR_MAX_CODE) ? MIRROR_MAX_CODE : result;
            return true;
        }
    }

    ADC1->CR |= ADC_CR_ADSTP;
    return false;
}

void voltage_mirror_write(uint16_t code)
{
    /* TODO 3: limit code to 0..4095 and write DAC->DHR12R1. */
    if (code > MIRROR_MAX_CODE) code = MIRROR_MAX_CODE;
    DAC->DHR12R1 = code;
}

uint16_t voltage_mirror_map(uint16_t code, bool coarse)
{
    /* TODO 4: limit code to 0..4095. FULL passes it through; COARSE keeps
     * the six most significant bits and clears the six least significant.
     * Retain the 12-bit DAC scale: do not send a 0..63 code directly.
     */
    if (code > MIRROR_MAX_CODE) code = MIRROR_MAX_CODE;
    if (!coarse) return code;
    return (uint16_t)(code & 0x0fc0u);
}

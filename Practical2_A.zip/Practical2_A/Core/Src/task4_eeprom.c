/**
  ******************************************************************************
  * @file    task4_eeprom.c
  * @brief   TASK 4 : EEPROM DRIVER
  *
  * Build the driver on spi_transfer() - no pre-written EEPROM library.
  * Command values, transaction order and status bits come from the EEPROM
  * datasheet; the address format for this board is in board_config.h.
  *
  * Write completion must be decided from the EEPROM's status register. A fixed
  * delay is not acceptable as proof that a write finished. Blocking while you
  * poll is allowed in Task 4.
  ******************************************************************************
  */

#include "prac2a.h"

volatile uint16_t eeprom_test_addr        = (uint16_t)EEPROM_ADDR_A;
volatile uint8_t  eeprom_test_byte        = (uint8_t)TEST_BYTE_B;

volatile uint8_t  eeprom_status_before    = 0u;
volatile uint8_t  eeprom_status_after     = 0u;
volatile uint8_t  eeprom_read_value       = 0u;
volatile uint8_t  eeprom_verify_ok        = 0u;
volatile uint32_t eeprom_write_wait_ms    = 0u;
volatile uint32_t eeprom_timeout_count    = 0u;

/* ==========================================================================
 * Driver
 * ========================================================================== */

uint8_t eeprom_read_status(void)
{
    uint8_t status;
    eeprom_cs_low();
    (void)spi_transfer(EEPROM_CMD_RDSR);
    status = spi_transfer(0x00u);         /* Clock dummy byte to receive status */
    eeprom_cs_high();
    return status;
}

void eeprom_write_enable(void)
{
    eeprom_cs_low();
    (void)spi_transfer(EEPROM_CMD_WREN);
    eeprom_cs_high();                     /* WEL latch sets on this rising edge */
}

void eeprom_write_byte(uint16_t address, uint8_t value)
{
    uint32_t start;

    if (address >= EEPROM_SIZE_BYTES)
    {
        return;
    }

    eeprom_write_enable();                /* Enable writes first */

    eeprom_cs_low();
    (void)spi_transfer(EEPROM_CMD_WRITE);

    #if EEPROM_ADDR_BYTES == 2u
    (void)spi_transfer((uint8_t)(address >> 8)); /* Address MSB */
    #endif
    (void)spi_transfer((uint8_t)(address & 0xFFu)); /* Address LSB */

    (void)spi_transfer(value);            /* Send data byte */
    eeprom_cs_high();                     /* Internal self-timed write starts here */

    start = HAL_GetTick();

    /* Poll status register until WIP (Bit 0) clears */
    while ((eeprom_read_status() & 0x01u) != 0u)
    {
        if ((uint32_t)(HAL_GetTick() - start) > EEPROM_WRITE_TIMEOUT_MS)
        {
            eeprom_timeout_count++;
            break;
        }
    }

    eeprom_write_wait_ms = (uint32_t)(HAL_GetTick() - start);
}

uint8_t eeprom_read_byte(uint16_t address)
{
    volatile uint8_t data;

    if (address >= EEPROM_SIZE_BYTES)
    {
        return 0u;
    }

    eeprom_cs_low();
    (void)spi_transfer(EEPROM_CMD_READ);

    #if EEPROM_ADDR_BYTES == 2u
    (void)spi_transfer((uint8_t)(address >> 8)); /* Address MSB */
    #endif
    (void)spi_transfer((uint8_t)(address & 0xFFu)); /* Address LSB */

    data = spi_transfer(0x00u);           /* Clock dummy byte to receive data */
    eeprom_cs_high();

    return data;
}

/* ==========================================================================
 * LEDs
 * ========================================================================== */

void leds_write_byte(uint8_t v)
{
    /* Atomic single-write: clear lower 8 pins (upper 16 bits of BSRR) and set v */
    GPIOB->BSRR = (0x00FFu << 16) | (uint32_t)v;
}

/* ==========================================================================
 * High-level paths
 * ========================================================================== */

void eeprom_read_only_path(void)
{
    eeprom_status_before = eeprom_read_status();
    eeprom_read_value    = eeprom_read_byte(eeprom_test_addr);
    eeprom_verify_ok     = (eeprom_read_value == eeprom_test_byte) ? 1u : 0u;
    leds_write_byte(eeprom_read_value);
    status_leds_show(eeprom_verify_ok ? STATUS_PASS : STATUS_FAIL);
}

void eeprom_write_verify_path(void)
{
    eeprom_status_before = eeprom_read_status();
    eeprom_write_byte(eeprom_test_addr, eeprom_test_byte);
    eeprom_status_after  = eeprom_read_status();
    eeprom_read_value    = eeprom_read_byte(eeprom_test_addr);
    eeprom_verify_ok     = (eeprom_read_value == eeprom_test_byte) ? 1u : 0u;

    leds_write_byte(eeprom_read_value);
    status_leds_show(eeprom_verify_ok ? STATUS_PASS : STATUS_FAIL);
}

/* ==========================================================================
 * RUN_TASK 4 (and 5) - given
 * ========================================================================== */

#define EEPROM_READ_LOOP_MS  50u

volatile uint8_t eeprom_read_loop_enable = 0u;

static uint32_t rd_last = 0u;
static uint8_t btn_last_state = 0u;

void task4_setup(void)
{
    task1_gpio_init();
    eeprom_spi_init();
    board_io_init();
    eeprom_read_only_path();
}

void task4_loop(uint32_t now)
{
    task1_gpio_update(now);
    read_inputs(now);

    /* Robust button detection: checks both standard flag and direct pin state */
    uint8_t btn_current = (uint8_t)button_pressed(BTN_START_PIN);
    uint8_t trigger_write = 0u;

    if (btn_start_edge)
    {
        btn_start_edge = 0u;
        trigger_write = 1u;
    }
    else if (btn_current && !btn_last_state)
    {
        trigger_write = 1u; /* Direct rising edge fallback */
    }
    btn_last_state = btn_current;

    if (trigger_write)
    {
        eeprom_write_verify_path();     /* one press, one write */
    }

    btn_abort_edge = 0u;

    if (eeprom_read_loop_enable && ((uint32_t)(now - rd_last) >= EEPROM_READ_LOOP_MS))
    {
        rd_last = now;
        eeprom_read_only_path();
    }
}

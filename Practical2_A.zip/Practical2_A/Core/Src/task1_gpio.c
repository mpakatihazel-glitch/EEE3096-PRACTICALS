/**
  ******************************************************************************
  * @file    task1_gpio.c
  * @brief   TASK 1 : MEMORY-MAPPED GPIO ACCESS
  *
  * Drive PC13 as a digital output using EXPLICIT volatile register pointers,
  * built from addresses you find in RM0091:
  *
  *     register address = peripheral base address + register offset
  *
  * Do not use HAL_GPIO_Init(), HAL_GPIO_WritePin() or HAL_GPIO_TogglePin().
  * You must be able to show where every base and offset came from.
  ******************************************************************************
  */

#include "prac2a.h"

/* TODO 1.1 Peripheral base addresses from RM0091 section 2 (Memory Map) */
#define RCC_BASE_ADDR       0x40021000UL    /* AHB1 peripheral bus: RCC */
#define GPIOC_BASE_ADDR     0x48000800UL    /* AHB2 peripheral bus: GPIOC */

/* TODO 1.2 Register offsets from RM0091 RCC & GPIO register maps */
#define RCC_AHBENR_OFFSET   0x14UL          /* AHB peripheral clock enable register */
#define GPIO_MODER_OFFSET   0x00UL          /* GPIO port mode register */
#define GPIO_ODR_OFFSET     0x14UL          /* GPIO port output data register */
#define GPIO_BSRR_OFFSET    0x18UL          /* GPIO port bit set/reset register */
#define GPIO_BRR_OFFSET     0x28UL          /* GPIO port bit reset register */

/* TODO 1.3 Declare explicit volatile pointers for all required GPIOC registers */
static volatile uint32_t * const pRCC_AHBENR =
        (volatile uint32_t *)(RCC_BASE_ADDR + RCC_AHBENR_OFFSET);
static volatile uint32_t * const pGPIOC_MODER =
        (volatile uint32_t *)(GPIOC_BASE_ADDR + GPIO_MODER_OFFSET);
static volatile uint32_t * const pGPIOC_ODR =
        (volatile uint32_t *)(GPIOC_BASE_ADDR + GPIO_ODR_OFFSET);
static volatile uint32_t * const pGPIOC_BSRR =
        (volatile uint32_t *)(GPIOC_BASE_ADDR + GPIO_BSRR_OFFSET);
static volatile uint32_t * const pGPIOC_BRR =
        (volatile uint32_t *)(GPIOC_BASE_ADDR + GPIO_BRR_OFFSET);

/* TODO 1.4 Static assertion checks against CMSIS definitions */
_Static_assert(RCC_BASE_ADDR   == RCC_BASE,   "RCC base mismatch");
_Static_assert(GPIOC_BASE_ADDR == GPIOC_BASE, "GPIOC base mismatch");
_Static_assert(RCC_BASE_ADDR + RCC_AHBENR_OFFSET
               == (uint32_t)(uintptr_t)&RCC->AHBENR,  "AHBENR offset");
_Static_assert(GPIOC_BASE_ADDR + GPIO_MODER_OFFSET
               == (uint32_t)(uintptr_t)&GPIOC->MODER, "MODER offset");
_Static_assert(GPIOC_BASE_ADDR + GPIO_ODR_OFFSET
               == (uint32_t)(uintptr_t)&GPIOC->ODR,   "ODR offset");
_Static_assert(GPIOC_BASE_ADDR + GPIO_BSRR_OFFSET
               == (uint32_t)(uintptr_t)&GPIOC->BSRR,  "BSRR offset");
_Static_assert(GPIOC_BASE_ADDR + GPIO_BRR_OFFSET
               == (uint32_t)(uintptr_t)&GPIOC->BRR,   "BRR offset");

volatile uint32_t task1_half_period_ms = 5u;
volatile uint32_t task1_toggle_count   = 0u;

static uint32_t t1_last = 0u;

void task1_gpio_init(void)
{
    /* TODO 1.5 Enable GPIOC clock via Bit 19 (IOPCEN) using Read-Modify-Write */
    *pRCC_AHBENR |= (1u << 19);

    /* TODO 1.6 Configure PC13 as Output mode (01) */
    *pGPIOC_MODER &= ~(3u << (13 * 2)); /* Clear bits 27:26 */
    *pGPIOC_MODER |=  (1u << (13 * 2)); /* Set bit 26 (01 = General Purpose Output) */

    /* TODO 1.7 Drive PC13 to initial LOW level */
    *pGPIOC_ODR &= ~(1u << 13);
}

void task1_gpio_update(uint32_t now)
{
    if ((uint32_t)(now - t1_last) < task1_half_period_ms)
    {
        return;
    }
    t1_last = now;

    /* TODO 1.8 Toggle PC13 state using XOR on ODR Bit 13 */
    *pGPIOC_ODR ^= (1u << 13);

    task1_toggle_count++;
}

/* ==========================================================================
 * RUN_TASK 1 - given
 * ========================================================================== */

void task1_setup(void)
{
    task1_gpio_init();
}

void task1_loop(uint32_t now)
{
    task1_gpio_update(now);
}

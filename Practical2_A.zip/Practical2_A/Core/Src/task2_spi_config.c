/**
  ******************************************************************************
  * @file    task2_spi_config.c
  * @brief   TASK 2 : CONFIGURE THE HARDWARE SPI PERIPHERAL
  *
  * Configure the SPI peripheral entirely through its registers. Not allowed:
  * HAL_SPI_*, LL SPI transfer functions, CubeMX-generated SPI configuration,
  * GPIO bit-banging. Every register write you add should cite the RM0091
  * register it comes from.
  ******************************************************************************
  */

#include "prac2a.h"

volatile uint32_t dbg_gpiob_moder      = 0u;
volatile uint32_t dbg_gpiob_afrh       = 0u;
volatile uint32_t dbg_spi_cr1          = 0u;
volatile uint32_t dbg_spi_cr2          = 0u;
volatile uint32_t dbg_spi_sr           = 0u;
volatile uint32_t dbg_sck_hz_predicted = 0u;

/* Bit-field values used below (RM0091 section 28.9 "SPI registers") */
#define GPIO_MODE_OUTPUT_V      1u      /* MODER 01 : general purpose output */
#define GPIO_MODE_AF_V          2u      /* MODER 10 : alternate function     */
#define GPIO_SPEED_HIGH_V       3u      /* OSPEEDR x1 : high speed           */
#define GPIO_PULLUP_V           1u      /* PUPDR 01 : pull-up                */

void eeprom_spi_init(void)
{
    uint32_t r;
    const uint32_t spi_pins_moder_mask = MODER2_MASK(EE_PIN_SCK)
                                       | MODER2_MASK(EE_PIN_MISO)
                                       | MODER2_MASK(EE_PIN_MOSI);

    /* TODO 2.4  Clocks.
     *   RCC_AHBENR  bit 18 IOPBEN : GPIOB clock   (RM0091 7.4.6)
     *   RCC_APB1ENR bit 14 SPI2EN : SPI2 clock    (RM0091 7.4.8)
     * Then pulse RCC_APB1RSTR bit 14 SPI2RST (RM0091 7.4.5) so SPI2 always
     * starts from its documented reset values, even after a debugger restart. */


    RCC->AHBENR  |= RCC_AHBENR_GPIOBEN;
    RCC->APB1ENR |= RCC_APB1ENR_SPI2EN;
    (void)RCC->APB1ENR;
    RCC->APB1RSTR |=  RCC_APB1RSTR_SPI2RST;
    RCC->APB1RSTR &= ~RCC_APB1RSTR_SPI2RST;

    /* TODO 2.5  Chip select PB12: drive the output latch HIGH first (BSRR),
     * THEN switch the pin to output. If MODER were written first the pin would
     * briefly drive the reset ODR value (0) and select the EEPROM with no valid
     * command. CS# is active low; high = EEPROM deselected, SO high-Z, and it
     * ignores SCK/SI - so nothing we clock during set-up (or Task 3) reaches it. */


    EE_SPI_GPIO->BSRR = EE_CS_MASK;                              /* 8.4.7 */
    r = EE_SPI_GPIO->MODER;
    r = (r & ~MODER2_MASK(EE_PIN_CS)) | MODER2(EE_PIN_CS, GPIO_MODE_OUTPUT_V);
    EE_SPI_GPIO->MODER = r;                                      /* 8.4.1 */
    EE_SPI_GPIO->OTYPER &= ~EE_CS_MASK;                          /* push-pull */

    /* TODO 2.6  PB13/14/15 -> alternate function (MODER = 10) and AF0 in
     *
     * GPIOB_AFRH (RM0091 9.4.10; AFSELy at bits 4(y-8)+3..4(y-8)).
     * AFR is written before MODER so the pin is never connected to a wrong AF. */


    r = EE_SPI_GPIO->AFR[1];
    r &= ~(AFRH4_MASK(EE_PIN_SCK) | AFRH4_MASK(EE_PIN_MISO) | AFRH4_MASK(EE_PIN_MOSI));
    r |=   AFRH4(EE_PIN_SCK, EE_SPI_AF) | AFRH4(EE_PIN_MISO, EE_SPI_AF)
         | AFRH4(EE_PIN_MOSI, EE_SPI_AF);
    EE_SPI_GPIO->AFR[1] = r;

    r = EE_SPI_GPIO->MODER;
    r &= ~spi_pins_moder_mask;
    r |=   MODER2(EE_PIN_SCK,  GPIO_MODE_AF_V)
         | MODER2(EE_PIN_MISO, GPIO_MODE_AF_V)
         | MODER2(EE_PIN_MOSI, GPIO_MODE_AF_V);
    EE_SPI_GPIO->MODER = r;

    /* TODO 2.7  High speed on SCK and MOSI (OSPEEDR, RM0091 9.4.3) and a
     * pull-up on MISO (PUPDR, RM0091 9.4.4). While CS# is high the EEPROM puts
     * SO in high impedance: without a pull-up PB14 floats and can read random
     * values / draw shoot-through current in the input buffer. */
    r = EE_SPI_GPIO->OSPEEDR;
    r &= ~(MODER2_MASK(EE_PIN_SCK) | MODER2_MASK(EE_PIN_MOSI) | MODER2_MASK(EE_PIN_CS));
    r |=   MODER2(EE_PIN_SCK,  GPIO_SPEED_HIGH_V) | MODER2(EE_PIN_MOSI, GPIO_SPEED_HIGH_V)
         | MODER2(EE_PIN_CS,   GPIO_SPEED_HIGH_V);
    EE_SPI_GPIO->OSPEEDR = r;

    r = EE_SPI_GPIO->PUPDR;
    r &= ~(MODER2_MASK(EE_PIN_SCK) | MODER2_MASK(EE_PIN_MISO) | MODER2_MASK(EE_PIN_MOSI)
           | MODER2_MASK(EE_PIN_CS));
    r |=   MODER2(EE_PIN_MISO, GPIO_PULLUP_V);
    EE_SPI_GPIO->PUPDR = r;

    /* Make sure the peripheral is disabled while it is configured
     * (RM0091 28.5.7: configuration changes with SPE = 0). */
    EE_SPI->CR1 &= ~SPI_CR1_SPE;

    /* TODO 2.8  SPI_CR2 (RM0091 28.9.2):
     *   DS[3:0]  = 0111 : 8-bit data frame
     *   FRXTH    = 1    : RXNE is set when the RX FIFO holds >= 8 bits.
     *                     (Reset value 0 needs 16 bits, so a single-byte
     *                     transfer would never raise RXNE.)
     *   SSOE = 0, no interrupts, no DMA, Motorola frame format (FRF = 0). */
    EE_SPI->CR2 = (7UL << SPI_CR2_DS_Pos) | SPI_CR2_FRXTH;

    /* TODO 2.9  SPI_CR1 (RM0091 28.9.1):
     *   MSTR     = 1          : master
     *   BR[2:0]  = EE_SPI_BR  : f_PCLK / 32 = 250 kHz
     *   CPOL     = 0          : SCK idles LOW
     *   CPHA     = 0          : data captured on the FIRST (rising) edge
     *                           -> SPI mode 0, supported by the EEPROM
     *                           (datasheet: modes 0 and 3; SI latched on
     *                           rising SCK, SO changes on falling SCK)
     *   LSBFIRST = 0          : MSB transmitted first (EEPROM requirement)
     *   SSM = 1, SSI = 1      : software slave management, internal NSS held
     *                           high, so the master never sees a mode fault
     *                           (MODF) and drops out of master mode.
     *   BIDIMODE/RXONLY/CRCEN = 0 : full duplex, no CRC. */
    EE_SPI->CR1 = SPI_CR1_MSTR
                | (EE_SPI_BR << SPI_CR1_BR_Pos)
                | SPI_CR1_SSM | SPI_CR1_SSI;
    /* CPOL = 0, CPHA = 0, LSBFIRST = 0 are left cleared on purpose. */

    /* Task 5 fault case. Leave this call exactly here: after your CR1 and CR2
     * configuration, before the peripheral is enabled. It does nothing unless
     * RUN_TASK is 5. */
    task5_fault_hook();


    /* THE TASK 5 FIX: The fault hook forced CPHA (Bit 0) to 1.
           We must clear Bit 0 to restore CPHA to 0 (SPI Mode 0). */
         EE_SPI->CR1 &= ~SPI_CR1_CPHA;

    /* TODO 2.10  Enable the peripheral: SPE = 1 (CR1 bit 6). */
    EE_SPI->CR1 |= SPI_CR1_SPE;

    dbg_gpiob_moder      = EE_SPI_GPIO->MODER;
    dbg_gpiob_afrh       = EE_SPI_GPIO->AFR[1];
    dbg_spi_cr1          = EE_SPI->CR1;
    dbg_spi_cr2          = EE_SPI->CR2;
    dbg_spi_sr           = EE_SPI->SR;
    dbg_sck_hz_predicted = EE_SCK_HZ_PREDICTED;
}

/* ==========================================================================
 * RUN_TASK 2 - given
 * Configures SPI and then does nothing else, so you can inspect the selected
 * SPI peripheral and GPIOB in the SFR view (or the dbg_* variables) while the
 * program runs. PC13 keeps toggling so you can see the program has not hung.
 * ========================================================================== */

void task2_setup(void)
{
    task1_gpio_init();
    eeprom_spi_init();
    while (1) { }
}

void task2_loop(uint32_t now)
{
    task1_gpio_update(now);
}

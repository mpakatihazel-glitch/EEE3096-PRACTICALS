/**
  ******************************************************************************
  * @file    task6_fsm.c
  * @brief   TASK 6 : NON-BLOCKING EEPROM TRANSACTION STATE MACHINE
  *
  * Restructure the Task 4 transaction so the main loop never stops:
  *
  *   request -> write-enable -> write -> wait for EEPROM
  *           -> read-back -> verify -> result
  *
  * Rules (handout, Task 6):
  *   - No HAL_Delay(), and no software busy-wait for the EEPROM's internal
  *     write cycle. You may use HAL_GetTick() to decide when the next status
  *     check is due.
  *   - Each call does a small amount of work, updates the state, and returns.
  *   - Do not put the whole transaction inside one blocking function called
  *     from the loop.
  *   - While a transaction is in progress the loop must still respond to PA3.
  *
  * Controls: PA0 starts, PA3 aborts. PB0..PB7 show the last byte read, PB11
  * (green) a successful verification, PB10 (red) a failed one.
  ******************************************************************************
  */

#include "prac2a.h"

/* TODO 6.1  States (numeric values are what `ee_state` shows in the debugger).
 *
 *  IDLE(0) --PA0--> PREP(1)
 *  PREP        : RDSR. RDY#=1 (device still busy from an earlier write)
 *                -> stay, re-check in 1 ms; >50 ms -> FAIL.
 *                RDY#=0 -> send WREN (own CS frame)            -> CHECK_WEL
 *  CHECK_WEL(2): RDSR. WEL=1 -> WRITE ; WEL=0 -> FAIL
 *  WRITE(3)    : CS low, WRITE, A15..8, A7..0, data, CS high (starts tWC)
 *                -> BUSY (record start time)
 *  BUSY(4)     : returns immediately until 1 ms since last poll, then RDSR:
 *                RDY#=0 -> READ ; RDY#=1 and < 50 ms -> stay ; >= 50 ms -> FAIL
 *  READ(5)     : CS low, READ, A15..8, A7..0, dummy -> byte, CS high -> VERIFY
 *  VERIFY(6)   : byte == written ? SUCCESS : FAIL
 *  SUCCESS(7) / FAIL(8) : result held on LEDs;  PA0 -> PREP (new transaction)
 *  any active state --PA3--> ABORTED(9) --(next pass)--> IDLE
 *  (PA3 in IDLE/SUCCESS/FAIL just clears the result -> IDLE)
 */
typedef enum
{
    EE_IDLE = 0,
    EE_PREP,            /* 1  write preparation: ready check + WREN         */
    EE_CHECK_WEL,       /* 2  confirm write-enable latch                    */
    EE_WRITE,           /* 3  write transaction                             */
    EE_BUSY,            /* 4  EEPROM busy / status checking                 */
    EE_READ,            /* 5  read-back transaction                         */
    EE_VERIFY,          /* 6  compare                                       */
    EE_SUCCESS,         /* 7  result: pass                                  */
    EE_FAIL,            /* 8  result: fail                                  */
    EE_ABORTED          /* 9  transient: PA3 pressed                        */
} ee_state_t;


volatile uint32_t ee_poll_interval_ms = 1u;
#define EE_POLL_INTERVAL_MS     (ee_poll_interval_ms)

volatile uint8_t ee_state       = EE_IDLE;
volatile uint8_t ee_last_read   = 0u;
volatile uint8_t ee_use_fsm     = 1u;

/* Debug / evidence */
volatile uint32_t ee_poll_count     = 0u;   /* status polls in last write    */
volatile uint32_t ee_write_time_ms  = 0u;   /* measured write-cycle time     */
volatile uint32_t ee_loop_count     = 0u;   /* main-loop passes (keeps rising
                                               during a write => non-blocking) */
volatile uint8_t  ee_fail_reason    = 0u;   /* 1 busy timeout before write,
                                               2 WEL not set, 3 write timeout,
                                               4 verify mismatch              */

static uint16_t     fsm_addr;
static uint8_t      fsm_data;
static uint32_t     fsm_t_start;
static uint32_t     fsm_t_last_poll;
static status_led_t idle_status = STATUS_OFF;   /* what IDLE shows          */

static void fsm_fail(uint8_t reason)
{
    ee_fail_reason = reason;
    ee_state       = EE_FAIL;
}

void update_eeprom_state_machine(uint32_t now)
{
    uint8_t sr;

    ee_loop_count++;

    /* ---- Abort has priority: checked every pass, in every state --------- */
    if (btn_abort_edge)
    {
        btn_abort_edge = 0u;
        /* Every SPI frame is started and finished inside a single call, so
         * between calls CS# is already high and the SPI is idle. Raise CS
         * anyway (it waits for BSY = 0) so the next transaction starts from a
         * clean bus. A write cycle already started inside the EEPROM cannot
         * be stopped - PREP checks RDY# before the next transaction. */
        eeprom_cs_high();
        idle_status = STATUS_OFF;
        ee_state    = (ee_state == EE_IDLE) ? EE_IDLE : EE_ABORTED;
        btn_start_edge = 0u;                /* ignore a simultaneous start   */
        return;
    }

    switch ((ee_state_t)ee_state)
    {
    case EE_IDLE:
    case EE_SUCCESS:
    case EE_FAIL:
        if (btn_start_edge)
        {
            btn_start_edge  = 0u;
            fsm_addr        = eeprom_test_addr;     /* latch request         */
            fsm_data        = eeprom_test_byte;
            ee_fail_reason  = 0u;
            ee_poll_count   = 0u;
            fsm_t_start     = now;
            fsm_t_last_poll = now - EE_POLL_INTERVAL_MS;   /* poll at once   */
            ee_state        = EE_PREP;
        }
        break;

    case EE_PREP:
        if ((uint32_t)(now - fsm_t_last_poll) < EE_POLL_INTERVAL_MS)
        {
            break;                                  /* not due yet: return   */
        }
        fsm_t_last_poll = now;
        sr = eeprom_read_status();
        eeprom_status_before = sr;
        if (sr & EEPROM_SR_RDY)
        {
            if ((uint32_t)(now - fsm_t_start) >= EEPROM_WRITE_TIMEOUT_MS)
            {
                fsm_fail(1u);
            }
            break;                                  /* still busy: return    */
        }
        eeprom_write_enable();                      /* one CS frame: WREN    */
        ee_state = EE_CHECK_WEL;
        break;

    case EE_CHECK_WEL:
        sr = eeprom_read_status();
        ee_state = (sr & EEPROM_SR_WEL) ? EE_WRITE : EE_FAIL;
        if (ee_state == EE_FAIL) { ee_fail_reason = 2u; }
        break;

    case EE_WRITE:
        eeprom_cs_low();
        (void)spi_transfer(EEPROM_CMD_WRITE);
#if (EEPROM_ADDR_BYTES == 2u)
        (void)spi_transfer((uint8_t)(fsm_addr >> 8));
#endif
        (void)spi_transfer((uint8_t)(fsm_addr & 0xFFu));
        (void)spi_transfer(fsm_data);
        eeprom_cs_high();                           /* tWC starts here       */
        fsm_t_start     = now;
        fsm_t_last_poll = now;
        ee_state        = EE_BUSY;
        break;

    case EE_BUSY:
        /* NOT a wait loop: if the next poll is not due, return at once and
         * let the main loop run (PA3, PC13 heartbeat, ...). */
        if ((uint32_t)(now - fsm_t_last_poll) < EE_POLL_INTERVAL_MS)
        {
            break;
        }
        fsm_t_last_poll = now;
        ee_poll_count++;
        sr = eeprom_read_status();
        if ((sr & EEPROM_SR_RDY) == 0u)
        {
            ee_write_time_ms    = (uint32_t)(now - fsm_t_start);
            eeprom_write_wait_ms = ee_write_time_ms;
            eeprom_status_after = sr;
            ee_state = EE_READ;                     /* decided by RDY# only  */
        }
        else if ((uint32_t)(now - fsm_t_start) >= EEPROM_WRITE_TIMEOUT_MS)
        {
            eeprom_timeout_count++;
            fsm_fail(3u);                           /* never became ready    */
        }
        break;

    case EE_READ:
        ee_last_read      = eeprom_read_byte(fsm_addr);
        eeprom_read_value = ee_last_read;
        ee_state          = EE_VERIFY;
        break;

    case EE_VERIFY:
        eeprom_verify_ok = (ee_last_read == fsm_data) ? 1u : 0u;
        if (eeprom_verify_ok) { ee_state = EE_SUCCESS; }
        else                  { fsm_fail(4u); }
        break;

    case EE_ABORTED:
        ee_state = EE_IDLE;
        break;

    default:
        eeprom_cs_high();
        ee_state = EE_IDLE;
        break;
    }

    /* A start press while a transaction is active is ignored (not queued). */
    if ((ee_state != EE_IDLE) && (ee_state != EE_SUCCESS) && (ee_state != EE_FAIL))
    {
        btn_start_edge = 0u;
    }
}

void update_outputs(void)
{
    /* TODO 6.3  PB0..PB7 = last byte read. Status LEDs: green on SUCCESS,
     * red on FAIL, both OFF while a transaction is running and after an
     * abort; in IDLE show the boot-time read-only result (persistence). */
    leds_write_byte(ee_last_read);

    switch ((ee_state_t)ee_state)
    {
    case EE_SUCCESS: status_leds_show(STATUS_PASS); break;
    case EE_FAIL:    status_leds_show(STATUS_FAIL); break;
    case EE_IDLE:    status_leds_show(idle_status); break;
    default:         status_leds_show(STATUS_OFF);  break;
    }
}

/* ==========================================================================
 * RUN_TASK 6 - given
 *
 * The main loop has exactly the shape the handout asks for:
 *     read_inputs();  update_eeprom_state_machine();  update_outputs();
 *
 * Set ee_use_fsm = 0 in Live Expressions to run the Task 4 blocking path on
 * PA0 instead - useful when you explain why yours is non-blocking. PC13 keeps
 * toggling as a heartbeat; watch it on the scope in both modes.
 * ========================================================================== */

void task6_setup(void)
{
    task1_gpio_init();
    eeprom_spi_init();
    board_io_init();

    eeprom_read_only_path();
    ee_last_read = eeprom_read_value;

    /* TODO 6.4  Start in IDLE, showing the boot-time read-only result. */
    ee_state    = EE_IDLE;
    idle_status = eeprom_verify_ok ? STATUS_PASS : STATUS_FAIL;
    update_outputs();
}

void task6_loop(uint32_t now)
{
    task1_gpio_update(now);
    read_inputs(now);

    if (ee_use_fsm)
    {
        update_eeprom_state_machine(now);
        update_outputs();
    }
    else
    {
        if (btn_start_edge)
        {
            btn_start_edge = 0u;
            eeprom_write_verify_path();     /* Task 4: blocks for the write */
            ee_last_read = eeprom_read_value;
        }
        btn_abort_edge = 0u;
    }
}

/**
  ******************************************************************************
  * @file    task3_spi_transfer.c
  * @brief   TASK 3 : SEND ONE BYTE AND PROVE THE WAVEFORM
  ******************************************************************************
  */

#include "prac2a.h"

/* ==========================================================================
 * Chip select
 * ========================================================================== */

void eeprom_cs_low(void)
{
    EE_SPI_GPIO->BRR = EE_CS_MASK;          /* RM0091 GPIOx_BRR             */
}

void eeprom_cs_high(void)
{
    /* TODO 3.3  RM0091 28.5.9 "Procedure for disabling the SPI" (full-duplex
     * master): wait until FTLVL[1:0] = 00 (TX FIFO empty, nothing left to
     * send), then until BSY = 0 (the last frame has completely left the shift
     * register). Only then is it safe to end the transaction. */
    while ((EE_SPI->SR & SPI_SR_FTLVL) != 0u) { }
    while ((EE_SPI->SR & SPI_SR_BSY) != 0u)   { }

    EE_SPI_GPIO->BSRR = EE_CS_MASK;         /* RM0091 GPIOx_BSRR, set PB12  */
}

/* ==========================================================================
 * TASK 3
 * ========================================================================== */

/* 8-bit views of SPI_DR. With DS = 8 bits the STM32F0 packs data by ACCESS
 * WIDTH (RM0091 28.5.9 "Data packing"): a 16-bit/32-bit write to DR puts TWO
 * frames in the TX FIFO (-> 16 SCK pulses), and a 16-bit read pops two. An
 * 8-bit access transfers exactly one frame. */
#define SPI_DR8     (*(volatile uint8_t *)&EE_SPI->DR)

uint8_t spi_transfer(uint8_t tx)
{
    /* TODO 3.4  Wait until TXE = 1 (SR bit 1): TX FIFO has room. */
    while ((EE_SPI->SR & SPI_SR_TXE) == 0u) { }

    /* TODO 3.5  Byte-wide write -> exactly 8 SCK pulses. Writing DR starts
     * the hardware shifting: SPI2 generates SCK and MOSI itself. */
    SPI_DR8 = tx;

    /* TODO 3.6  Wait until RXNE = 1 (SR bit 0; with FRXTH = 1 this means
     * >= 8 bits in the RX FIFO), then read the byte. SPI is full duplex: one
     * byte in for every byte out. Always reading keeps the RX FIFO empty so
     * old bytes never get returned for a later transfer and OVR never sets. */
    while ((EE_SPI->SR & SPI_SR_RXNE) == 0u) { }

    return SPI_DR8;
}

/* ==========================================================================
 * RUN_TASK 3 - given
 * Sends task3_test_byte every 100 ms with CS held HIGH, so the EEPROM ignores
 * it and your oscilloscope has a repeating burst to trigger on.
 * task3_test_byte can be changed from Live Expressions without a rebuild.
 * ========================================================================== */

#define TASK3_TX_PERIOD_MS  100u

volatile uint8_t  task3_test_byte = (uint8_t)TEST_BYTE_B;
volatile uint8_t  task3_rx_byte   = 0u;
volatile uint32_t task3_tx_count  = 0u;

static uint32_t t3_last = 0u;

void task3_setup(void)
{
    task1_gpio_init();
    eeprom_spi_init();
}

void task3_loop(uint32_t now)
{
    task1_gpio_update(now);

    if ((uint32_t)(now - t3_last) < TASK3_TX_PERIOD_MS)
    {
        return;
    }
    t3_last = now;

    task3_rx_byte = spi_transfer(task3_test_byte);
    task3_tx_count++;
}


